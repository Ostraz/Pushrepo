#!/bin/sh
javac -classpath .:../../../lib/sftp.jar -d . FtpMuploadExample.java
java -cp .:../../../lib/sftp.jar FtpMuploadExample
