#!/bin/sh
javac -classpath .:../../../lib/sftp.jar:../../../lib/bcprov-ext-jdk15on-148.jar -d . SFtpDownloadDirExample.java
java -cp .:../../../lib/sftp.jar:../../../lib/bcprov-ext-jdk15on-148.jar SFtpDownloadDirExample
