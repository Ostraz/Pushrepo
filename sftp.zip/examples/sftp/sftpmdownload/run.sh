#!/bin/sh
javac -classpath .:../../../lib/sftp.jar:../../../lib/bcprov-ext-jdk15on-148.jar -d . SFtpMdownloadExample.java
java -cp .:../../../lib/sftp.jar:../../../lib/bcprov-ext-jdk15on-148.jar SFtpMdownloadExample
