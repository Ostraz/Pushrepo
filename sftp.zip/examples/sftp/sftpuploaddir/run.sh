#!/bin/sh
javac -classpath .:../../../lib/sftp.jar:../../../lib/bcprov-ext-jdk15on-148.jar -d . SFtpUploadDirExample.java
java -cp .:../../../lib/sftp.jar:../../../lib/bcprov-ext-jdk15on-148.jar SFtpUploadDirExample
