#!/bin/sh
javac -classpath .:../../../lib/sftp.jar:../../../lib/bcprov-ext-jdk15on-148.jar -d . SFtpExample.java
java -cp .:../../../lib/sftp.jar:../../../lib/bcprov-ext-jdk15on-148.jar SFtpExample
