#!/bin/sh
java -jar ../../../lib/sftp.jar -f dirlisting.txt
