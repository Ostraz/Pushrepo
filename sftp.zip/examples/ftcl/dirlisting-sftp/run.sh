#!/bin/sh
java -jar ../../../lib/sftp.jar:../../../lib/bcprov-ext-jdk15on-148.jar -f dirlisting-sftp.txt
